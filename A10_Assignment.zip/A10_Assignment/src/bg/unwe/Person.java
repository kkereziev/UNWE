/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.unwe;

/**
 *
 * @author inf2065_usr
 */
public interface Person {
    public String getName();
    public void setName (String name);
    
}
