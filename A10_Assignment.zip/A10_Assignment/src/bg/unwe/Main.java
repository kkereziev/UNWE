/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.unwe;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author inf2065_usr
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        ArrayList<Course> courses = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            Course course = new Course();

            System.out.println("Course " + (i + 1) + "name:");
            String courseName = s.next();
            course.setName(courseName);
            System.out.print("Course " + (i + 1) + " students count: ");
            int studentsCount = s.nextInt();
            for (int j = 0; j < studentsCount; j++) {
                Student student = new Student();
                System.out.print("Student " + (j + 1) + "name");
                String studentName = s.next();
                student.setName(studentName);
                course.addStudent(student);
            }
            courses.add(course);

        }
        System.out.println("");
        for (int i = 0; i < courses.size(); i++) {
            System.out.print("Course "+(i+1)+": "+courses.get(i).getName());
            for (int j = 0; j < courses.get(i).getStudentsCount(); j++) {
                System.out.print(", Student "+(j+1)+": "+courses.get(i).getName());
            }
            System.out.println(" ");
        }

    }

}
