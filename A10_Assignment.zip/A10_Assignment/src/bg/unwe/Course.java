/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bg.unwe;

import java.util.ArrayList;

/**
 *
 * @author inf2065_usr
 */
public class Course {
    private String name;
    private ArrayList <Student> students;
    public Course(){
        students = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void addStudent(Student student){
        students.add(student);
    }
    public Student getStudent(int index){
        return students.get(index);
    }
    public int getStudentsCount(){
        return students.size();
    }
}
